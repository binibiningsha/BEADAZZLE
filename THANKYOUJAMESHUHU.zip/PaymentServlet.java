import com.adyen.Client;
import com.adyen.enums.Environment;
import com.adyen.model.checkout.*;
import com.adyen.service.checkout.PaymentsApi;
import com.google.gson.Gson;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PaymentController {

    private static final String API_KEY = "ADYEN_API_KEY"; 
    private static final String MERCHANT_ACCOUNT = "ADYEN_MERCHANT_ACCOUNT";

    @PostMapping("/process-payment")
    public ResponseEntity<String> processPayment(@RequestBody Map<String, Object> requestData) {
        Gson gson = new Gson();
        long amountValue = ((Number) requestData.get("amount")).longValue();
        String reference = (String) requestData.get("reference");

        try {
            // Initialize Adyen Client with API Key and Environment (Test or Live)
            Client client = new Client(API_KEY, Environment.TEST); 
            PaymentsApi service = new PaymentsApi(client);

            // Create Amount object for the payment
            Amount amount = new Amount();
            amount.setCurrency("PHP");
            amount.setValue(amountValue);

            // Set up the stored payment method details (e.g., GCash)
            StoredPaymentMethodDetails paymentMethodDetails = new StoredPaymentMethodDetails();
            paymentMethodDetails.setType(StoredPaymentMethodDetails.TypeEnum.GCASH);

            // Create a PaymentRequest with the reference and amount
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setReference(reference);
            paymentRequest.setAmount(amount);
            paymentRequest.setMerchantAccount(MERCHANT_ACCOUNT);
            paymentRequest.setPaymentMethod(paymentMethodDetails); // Use the correct type directly
            paymentRequest.setReturnUrl("https://yourwebsite.com/payment-success");

            // Send the payment request to Adyen
            PaymentResponse adyenResponse = service.payments(paymentRequest);

            // Return Adyen's response as JSON back to frontend
            return ResponseEntity.ok(gson.toJson(adyenResponse));
        } catch (Exception e) {
            // Handle errors and return appropriate response
            return ResponseEntity.status(500).body("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}
