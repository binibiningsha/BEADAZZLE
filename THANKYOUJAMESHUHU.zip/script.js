
let cart = [];
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");

document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", function () {
        let product = this.parentElement;
        let productName = product.querySelector("h3").innerText;
        let productPrice = parseInt(product.dataset.price);
        
        let item = cart.find(p => p.name === productName);
        if (item) {
            item.quantity++;
        } else {
            cart.push({ name: productName, price: productPrice, quantity: 1 });
        }
        updateCart();
    });
});

function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;
    cart.forEach(item => {
        let li = document.createElement("li");
        li.innerText = `${item.name} x${item.quantity} - ₱${item.price * item.quantity}`;
        cartItems.appendChild(li);
        total += item.price * item.quantity;
    });
    cartTotal.innerText = total;
}

document.getElementById("checkout").addEventListener("click", function () {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }
    window.location.href = "gcash_payment.html?total=" + cartTotal.innerText;
});