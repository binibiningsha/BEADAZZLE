import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @PostMapping("/process-payment")
    public ResponseEntity<String> processPayment(@RequestBody Map<String, Object> requestData) {
        try {
            // Check if the 'amount' is provided in the request
            if (requestData == null || !requestData.containsKey("amount")) {
                return ResponseEntity.badRequest().body("{\"status\": \"error\", \"message\": \"Amount is missing\"}");
            }

            // Extract the amount from the request data
            long amount = ((Number) requestData.get("amount")).longValue();

            // Log the processing of payment
            logger.info("Processing payment of amount: {}", amount);

            // Here you would normally process the payment, interact with an API, etc.
            // For now, we'll simulate success.

            // Returning a custom JSON response
            return ResponseEntity.ok().body("{\"status\": \"success\", \"message\": \"Payment processed successfully\", \"amount\": " + amount + "}");

        } catch (Exception e) {
            // Log the exception
            logger.error("Error processing payment", e);

            // Returning a custom error response
            return ResponseEntity.status(500).body("{\"status\": \"error\", \"message\": \"An error occurred while processing the payment\"}");
        }
    }
}
